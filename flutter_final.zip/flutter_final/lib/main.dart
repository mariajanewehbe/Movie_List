import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: LogoPage(),
    );
  }
}

class LogoPage extends StatelessWidget {
  String _title = 'Movie';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_title),
      ),
      body: Center(
      child: Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
    SizedBox(
    width: 300,
    height: 300,
    child: Image.asset('images/movie_logo.jpg'),
    ),
        Padding(padding: const EdgeInsets.all(16.0),
        child: ElevatedButton(
    child: Text('Show Movies'),
    onPressed: () {
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) =>
                  MovieList()));
    }
      )
      )
    ]
      )
    )
    );
}
}

class MovieList extends StatelessWidget {
  String _title = 'Movie List';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.indigo.shade50,
      appBar: AppBar(title: Text(_title)),
      body: ListView.builder(
        itemCount: movies.length,
        itemBuilder: (context, index) {
          return Card(
            elevation: 8,
            child: InkWell(
              splashColor: Colors.indigo.withAlpha(50),
              onTap: () {
                print('Card tapped.');
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            DetailScreen(movie: movies[index])));
              },
              child: Column(
                children: [
                  SizedBox(
                      width: double.infinity,
                      height: 200,
                      child: Image.asset(
                        movies[index].imageResource,
                        fit: BoxFit.fitWidth,
                      )),
                  Padding(
                    padding: const EdgeInsets.all(4.0),
                    child: Text(
                      movies[index].title,
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                  // Text(sushiPlates[index].nameEnglish)
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class DetailScreen extends StatelessWidget {
  final Movie movie;

  const DetailScreen({Key key, @required this.movie}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(title: Text(movie.title)),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(
              width: double.infinity,
              child: Image.asset(
                movie.imageResource,
                fit: BoxFit.fill,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                movie.title,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 24,
                ),
              ),
            ),
            Text(
              movie.desc,
              style: TextStyle(fontStyle: FontStyle.italic),
            )
          ],
        ),
      ),
    );
  }
}


class Movie {
  final String title;
  final String desc;
  final String imageResource;

  Movie(this.title, this.desc, this.imageResource);
}

final movies = [
  Movie('Dunkirk', 'A movie about a war.', 'images/dunkirk.jpg'),
  Movie('Harry Potter and the Deathly Hallows',
      'The last installment of Harry Potter', 'images/harry_potter.jpg'),
  Movie('La La Land', 'A musical where people find themselves.',
      'images/lalaland.jpg'),
  Movie('Tangled', "Disney's Rapunzel.", 'images/tangled.jpg'),
  Movie('Jumanji', 'Teenagers enter a video game.', 'images/jumanji.jpg')
];
