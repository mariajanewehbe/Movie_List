package com.wehbe.flutter_final

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
